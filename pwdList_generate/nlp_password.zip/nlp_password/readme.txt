语料库下载自:	https://corpus.byu.edu/coca/
			https://www.wordfrequency.info/5k_lemmas_download.asp
			https://www.ngrams.info/download_coca.asp

words_frequency.txt：COCA使用频率前5000的词汇['Word', 'Tag', 'Frequency', 'Dispersion']
w2c.txt：COCA使用频率前1048720的2-grams词汇[frequency word1 word2 tag1 tag2)]
w3c.txt：COCA使用频率前1048720的3-grams词汇['Frequency', 'Word1', 'Word2', 'Word3', 'Tag1', 'Tag2', 'Tag3']

names.csv 下载自https://www.ssa.gov/oact/babynames/limits.html
	为常用英文名[names, sex, counts]

main_countrys.csv 
	为世界主要国家名